-- Apagar tabelas antigas se existirem (para limpar a base de dados do zero)
DROP TABLE IF EXISTS item_venda CASCADE;
DROP TABLE IF EXISTS venda CASCADE;
DROP TABLE IF EXISTS produto CASCADE;
DROP TABLE IF EXISTS categoria CASCADE;

-- Criar a tabela de categorias
CREATE TABLE categoria (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Inserir as categorias principais com IDs fixos
INSERT INTO categoria (id, nome) VALUES (1, 'Cartas');
INSERT INTO categoria (id, nome) VALUES (2, 'Acessórios');
INSERT INTO categoria (id, nome) VALUES (3, 'Jogos de Tabuleiro');

-- Criar a tabela de produtos (com UNIQUE no nome para evitar duplicatas)
CREATE TABLE produto (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    preco NUMERIC(10, 2) NOT NULL,
    quantidade INT NOT NULL,
    categoria_id INT NOT NULL,
    CONSTRAINT fk_categoria FOREIGN KEY (categoria_id) REFERENCES categoria(id)
);

-- Inserir os produtos iniciais (com os preços corretos e ordem de IDs limpa)
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (1, 'Booster Pokémon TCG', 12.00, 20, 1);
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (2, 'Booster Yu-Gi-Oh!', 30.00, 50, 1);
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (3, 'Booster Magic', 25.00, 40, 1);
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (4, 'Sleeves/Protetores de Cartas (Pacote c/ 100)', 10.00, 60, 2);
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (5, 'Kit de Dados RPG', 45.00, 30, 2);
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (6, 'Catan - Jogo de Tabuleiro', 280.00, 10, 3);
INSERT INTO produto (id, nome, preco, quantidade, categoria_id) VALUES (7, 'Dixit - Jogo de Tabuleiro', 240.00, 12, 3);

-- Ajustar a sequência do ID do produto para continuar corretamente após o 7
SELECT setval('produto_id_seq', (SELECT MAX(id) FROM produto));

-- Criar a tabela de vendas
CREATE TABLE venda (
    id SERIAL PRIMARY KEY,
    data_venda TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valor_total NUMERIC(10, 2) NOT NULL
);

-- Criar a tabela de itens da venda
CREATE TABLE item_venda (
    id SERIAL PRIMARY KEY,
    venda_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade_vendida INT NOT NULL,
    preco_unitario NUMERIC(10, 2) NOT NULL,
    CONSTRAINT fk_venda FOREIGN KEY (venda_id) REFERENCES venda(id) ON DELETE CASCADE,
    CONSTRAINT fk_produto FOREIGN KEY (produto_id) REFERENCES produto(id)
);