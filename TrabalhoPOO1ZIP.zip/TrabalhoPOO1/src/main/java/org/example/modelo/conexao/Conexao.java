package org.example.modelo.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    private static final String URL = "jdbc:postgresql://localhost:5432/TrabalhoPOO";
    private static final String USER = "postgres";
    private static final String PASS = "Eduarda07#";

    public static Connection conectar() {
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Conexão efetuada com sucesso à base de dados!");
        } catch (SQLException e) {
            System.out.println("Erro ao conectar à base de dados: " + e.getMessage());
        }
        return conexao;
    }
}