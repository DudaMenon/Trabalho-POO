package org.example.modelo.dao;

import org.example.modelo.conexao.Conexao;
import org.example.modelo.entidades.ItemVenda;
import org.example.modelo.entidades.Venda;

import java.sql.*;

public class VendaDAO {

    public void finalizarVenda(Venda venda) {
        String sqlVenda = "INSERT INTO venda (valor_total) VALUES (?)";
        String sqlItem = "INSERT INTO item_venda (venda_id, produto_id, quantidade_vendida, preco_unitario) VALUES (?, ?, ?, ?)";
        String sqlAtualizaEstoque = "UPDATE produto SET quantidade = quantidade - ? WHERE id = ?";

        Connection conn = null;
        try {
            conn = Conexao.conectar();
            conn.setAutoCommit(false); // Inicia a transação com segurança


            try (PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda, Statement.RETURN_GENERATED_KEYS)) {
                stmtVenda.setDouble(1, venda.getValorTotal());
                stmtVenda.executeUpdate();

                try (ResultSet rs = stmtVenda.getGeneratedKeys()) {
                    if (rs.next()) {
                        venda.setId(rs.getInt(1));
                    }
                }
            }

            try (PreparedStatement stmtItem = conn.prepareStatement(sqlItem);
                 PreparedStatement stmtEstoque = conn.prepareStatement(sqlAtualizaEstoque)) {

                for (ItemVenda item : venda.getItens()) {
                    stmtItem.setInt(1, venda.getId());
                    stmtItem.setInt(2, item.getProduto().getId());
                    stmtItem.setInt(3, item.getQuantidadeVendida());
                    stmtItem.setDouble(4, item.getPrecoUnitario());
                    stmtItem.executeUpdate();

                    stmtEstoque.setInt(1, item.getQuantidadeVendida());
                    stmtEstoque.setInt(2, item.getProduto().getId());
                    stmtEstoque.executeUpdate();
                }
            }

            conn.commit(); // Confirma tudo se correr bem
            System.out.println("Venda registada com sucesso! ID da Venda: " + venda.getId());

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Reverte se houver erro
                    System.out.println("Erro na venda. Transação cancelada.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            System.out.println("Erro ao finalizar venda: " + e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}