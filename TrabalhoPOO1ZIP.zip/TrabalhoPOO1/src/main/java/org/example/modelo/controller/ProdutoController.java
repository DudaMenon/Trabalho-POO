package org.example.modelo.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.modelo.dao.ProdutoDAO;
import org.example.modelo.entidades.Categoria;
import org.example.modelo.entidades.Produto;

import java.util.List;

public class ProdutoController {

    @FXML private TextField txtNome;
    @FXML private TextField txtPreco;
    @FXML private TextField txtQuantidade;
    @FXML private TextField txtCategoriaId;

    @FXML private TableView<Produto> tabelaProdutos;
    @FXML private TableColumn<Produto, String> colNome;
    @FXML private TableColumn<Produto, Double> colPreco;
    @FXML private TableColumn<Produto, Integer> colQuantidade;
    @FXML private TableColumn<Produto, String> colCategoria;

    private ProdutoDAO produtoDAO = new ProdutoDAO();
    private ObservableList<Produto> listaProdutos;

    @FXML
    public void initialize() {
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));

        // Exibir o nome da categoria na coluna correspondente
        colCategoria.setCellValueFactory(cellData -> {
            Categoria cat = cellData.getValue().getCategoria();
            return new javafx.beans.property.SimpleStringProperty(cat != null ? cat.getNome() : "");
        });

        carregarTabela();

        // Listener para preencher os campos quando seleciona um item da tabela
        tabelaProdutos.getSelectionModel().selectedItemProperty().addListener((obs, antigo, novo) -> {
            if (novo != null) {
                txtNome.setText(novo.getNome());
                txtPreco.setText(String.valueOf(novo.getPreco()));
                txtQuantidade.setText(String.valueOf(novo.getQuantidade()));
                if (novo.getCategoria() != null) {
                    txtCategoriaId.setText(String.valueOf(novo.getCategoria().getId()));
                }
            }
        });
    }

    public void carregarTabela() {
        try {
            List<Produto> produtosFromDb = produtoDAO.listar();
            if (produtosFromDb != null) {
                listaProdutos = FXCollections.observableArrayList(produtosFromDb);
                tabelaProdutos.setItems(listaProdutos);
            }
        } catch (Exception e) {
            System.err.println("Erro ao carregar produtos:" + e.getMessage());
        }
    }

    @FXML
    private void handleInserir() {
        try {
            Produto p = new Produto();
            p.setNome(txtNome.getText());
            p.setPreco(Double.parseDouble(txtPreco.getText()));
            p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));

            Categoria cat = new Categoria();
            cat.setId(Integer.parseInt(txtCategoriaId.getText()));
            p.setCategoria(cat);

            produtoDAO.inserir(p);
            carregarTabela();
            showAlert("Sucesso", "Produto inserido com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Erro", "Erro ao inserir produto: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAtualizar() {
        Produto selecionado = tabelaProdutos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            showAlert("Aviso", "Selecione um produto na tabela para atualizar.", Alert.AlertType.WARNING);
            return;
        }

        try {
            selecionado.setNome(txtNome.getText());
            selecionado.setPreco(Double.parseDouble(txtPreco.getText()));
            selecionado.setQuantidade(Integer.parseInt(txtQuantidade.getText()));

            Categoria cat = new Categoria();
            cat.setId(Integer.parseInt(txtCategoriaId.getText()));
            selecionado.setCategoria(cat);

            produtoDAO.atualizar(selecionado);
            carregarTabela();
            showAlert("Sucesso", "Produto atualizado com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Erro", "Erro ao atualizar produto: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleExcluir() {
        Produto selecionado = tabelaProdutos.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            showAlert("Aviso", "Selecione um produto na tabela para excluir.", Alert.AlertType.WARNING);
            return;
        }

        try {
            produtoDAO.excluir(selecionado.getId());
            carregarTabela();
            showAlert("Sucesso", "Produto excluído com sucesso!", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            showAlert("Erro", "Erro ao excluir produto: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}