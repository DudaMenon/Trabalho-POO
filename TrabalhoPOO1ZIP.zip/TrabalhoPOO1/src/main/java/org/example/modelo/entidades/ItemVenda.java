package org.example.modelo.entidades;

public class ItemVenda {
    private int id;
    private Venda venda;
    private Produto produto;
    private int quantidadeVendida;
    private double precoUnitario;

    public ItemVenda() {}

    public ItemVenda(Venda venda, Produto produto, int quantidadeVendida, double precoUnitario) {
        this.venda = venda;
        this.produto = produto;
        this.quantidadeVendida = quantidadeVendida;
        this.precoUnitario = precoUnitario;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Venda getVenda() { return venda; }
    public void setVenda(Venda venda) { this.venda = venda; }

    public Produto getProduto() { return produto; }
    public void setProduto(Produto produto) { this.produto = produto; }

    public int getQuantidadeVendida() { return quantidadeVendida; }
    public void setQuantidadeVendida(int quantidadeVendida) { this.quantidadeVendida = quantidadeVendida; }

    public double getPrecoUnitario() { return precoUnitario; }
    public void setPrecoUnitario(double precoUnitario) { this.precoUnitario = precoUnitario; }
}