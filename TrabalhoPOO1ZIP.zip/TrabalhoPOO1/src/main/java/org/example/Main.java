package org.example;

import org.example.modelo.dao.ProdutoDAO;
import org.example.modelo.dao.VendaDAO;
import org.example.modelo.entidades.Categoria;
import org.example.modelo.entidades.ItemVenda;
import org.example.modelo.entidades.Produto;
import org.example.modelo.entidades.Venda;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        ProdutoDAO produtoDAO = new ProdutoDAO();

        // Categorias (IDs: 1 = Cartas, 2 = Acessórios, 3 = Jogos de Tabuleiro)
        Categoria catCartas = new Categoria();
        catCartas.setId(1);

        Categoria catAcessorios = new Categoria();
        catAcessorios.setId(2);

        Categoria catTabuleiro = new Categoria();
        catTabuleiro.setId(3);

        // Inserir os produtos
        System.out.println("A inserir produtos...");
        produtoDAO.inserir(newProduto("Booster Pokémon TCG", 12.00, 20, catCartas));
        produtoDAO.inserir(newProduto("Booster Yu-Gi-Oh!", 30.00, 50, catCartas));
        produtoDAO.inserir(newProduto("Booster Magic", 25.00, 40, catCartas));
        produtoDAO.inserir(newProduto("Sleeves/Protetores de Cartas (Pacote c/ 100)", 10.00, 60, catAcessorios));
        produtoDAO.inserir(newProduto("Kit de Dados RPG", 45.00, 30, catAcessorios));
        produtoDAO.inserir(newProduto("Catan - Jogo de Tabuleiro", 280.00, 10, catTabuleiro));
        produtoDAO.inserir(newProduto("Dixit - Jogo de Tabuleiro", 240.00, 12, catTabuleiro));

        // Listar todos os produtos
        System.out.println("\n--- Catálogo Atualizado da Loja ---");
        List<Produto> produtos = produtoDAO.listar();

        System.out.println("Quantidade de produtos encontrados na lista: " + produtos.size());

        for (Produto p : produtos) {
            System.out.println("ID: " + p.getId() +
                    " | Nome: " + p.getNome() +
                    " | Preço: R$ " + p.getPreco() +
                    " | Qtd: " + p.getQuantidade() +
                    " | Categoria: " + (p.getCategoria() != null ? p.getCategoria().getNome() : "Sem Categoria"));
        }

        // --- SIMULAÇÃO DE VENDA ---
        System.out.println("\n--- A Registar Venda ---");
        if (!produtos.isEmpty()) {
            Venda novaVenda = new Venda();

            // Comprar 2 unidades do Booster Pokémon (primeiro produto)
            Produto p1 = produtos.get(0);
            novaVenda.adicionarItem(new ItemVenda(novaVenda, p1, 2, p1.getPreco()));

            // Comprar 1 unidade do Catan (se existir na lista)
            if (produtos.size() >= 6) {
                Produto p6 = produtos.get(5);
                novaVenda.adicionarItem(new ItemVenda(novaVenda, p6, 1, p6.getPreco()));
            }

            // Gravar a venda na base de dados e atualizar o stock
            VendaDAO vendaDAO = new VendaDAO();
            vendaDAO.finalizarVenda(novaVenda);

            System.out.println("Valor Total da Venda: R$ " + novaVenda.getValorTotal());
        }
    }

    private static Produto newProduto(String nome, double preco, int qtd, Categoria categoria) {
        Produto p = new Produto();
        p.setNome(nome);
        p.setPreco(preco);
        p.setQuantidade(qtd);
        p.setCategoria(categoria);
        return p;
    }
}